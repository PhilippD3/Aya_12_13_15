﻿using System;

public class SingleRandomizer
{
    // Используем Lazy<T> для потокобезопасной инициализации
    private static readonly Lazy<SingleRandomizer> _instance = new Lazy<SingleRandomizer>(() => new SingleRandomizer());

    private readonly Random _random;

    private SingleRandomizer()
    {
        _random = new Random();
    }

    // Свойство для доступа к единственному экземпляру
    public static SingleRandomizer Instance => _instance.Value;

    public double GetNextNumber()
    {
        return _random.NextDouble();
    }
}

class Program
{
    static void Main()
    {
        var randomizer = SingleRandomizer.Instance;
        Console.WriteLine(randomizer.GetNextNumber());
    }
}
//«Одиночка» — паттерн, позволяющий создавать только один экземпляр заданного класса.

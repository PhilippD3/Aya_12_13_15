﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Timers;

public interface IFileSystemWatcherObserver
{
    void OnDirectoryChanged(string directoryPath);
}

public class FileSystemWatcherSimple
{
    private readonly string _directoryPath;
    private readonly List<IFileSystemWatcherObserver> _observers = new List<IFileSystemWatcherObserver>();
    private string[] _lastFileSnapshot;
    private System.Timers.Timer _timer;

    public FileSystemWatcherSimple(string directoryPath, double intervalInMilliseconds = 1000)
    {
        _directoryPath = directoryPath;
        _timer = new System.Timers.Timer(intervalInMilliseconds);
        _timer.Elapsed += (sender, e) => CheckForChanges();
        _lastFileSnapshot = GetCurrentFileSnapshot();
        _timer.Start();
    }

    public void AddObserver(IFileSystemWatcherObserver observer)
    {
        _observers.Add(observer);
    }

    public void RemoveObserver(IFileSystemWatcherObserver observer)
    {
        _observers.Remove(observer);
    }

    private void CheckForChanges()
    {
        var currentFiles = GetCurrentFileSnapshot();

        if (currentFiles.Length != _lastFileSnapshot.Length || !currentFiles.SequenceEqual(_lastFileSnapshot))
        {
            NotifyObservers();
            _lastFileSnapshot = currentFiles;
        }
    }

    private string[] GetCurrentFileSnapshot()
    {
        return Directory.GetFiles(_directoryPath);
    }

    private void NotifyObservers()
    {
        // Уведомляем всех наблюдателей об изменении
        foreach (var observer in _observers)
        {
            observer.OnDirectoryChanged(_directoryPath);
        }
    }
}

public class FileObserver : IFileSystemWatcherObserver
{
    public void OnDirectoryChanged(string directoryPath)
    {
        Console.WriteLine($"Директория '{directoryPath}' изменилась!");
    }
}

class Program
{
    static void Main()
    {
        string directoryToWatch = @"C:\TestDirectory"; 

        var watcher = new FileSystemWatcherSimple(directoryToWatch);

        var observer1 = new FileObserver();
        var observer2 = new FileObserver();

        watcher.AddObserver(observer1);
        watcher.AddObserver(observer2);

        Console.WriteLine("Наблюдатель за файловой системой запущен...");
        Console.WriteLine("Нажмите любую клавишу для завершения...");
        Console.ReadKey();

        watcher.RemoveObserver(observer1); 
    }
}
//Наблюдатель - это есть процесс, если в нём что-то изменяется, то это узнают все наблюдатели 
